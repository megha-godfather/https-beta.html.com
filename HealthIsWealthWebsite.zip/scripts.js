
document.getElementById('theme-toggle')?.addEventListener('change', toggleTheme);

function toggleTheme() {
    const body = document.body;
    if (body.style.backgroundColor === 'white') {
        body.style.backgroundColor = '#2c3e50';
        body.style.color = 'white';
    } else {
        body.style.backgroundColor = 'white';
        body.style.color = '#2c3e50';
    }
}
